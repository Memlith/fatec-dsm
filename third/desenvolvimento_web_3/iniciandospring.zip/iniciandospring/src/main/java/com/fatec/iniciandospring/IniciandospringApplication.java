package com.fatec.iniciandospring;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class IniciandospringApplication {

	public static void main(String[] args) {
		SpringApplication.run(IniciandospringApplication.class, args);
	}

}
