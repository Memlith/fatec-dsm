package com.fatec.iniciandospring;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class IniciandospringApplicationTests {

	@Test
	void contextLoads() {
	}

}
